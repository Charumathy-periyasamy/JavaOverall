package BankingApplication;

import java.util.Scanner;

public class bankingApplication {
	static String customerName;
	static int customerId ;
	int balanceAmount;
	int withdrawAmount;
	int depositAmount ;
	static Scanner s = new Scanner(System.in);
	public static void getData()
	{
	
		System.out.println("Enter customer name : ");
		 customerName = s.next();
		System.out.println("Enter customer id : ");
		 customerId = s.nextInt();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		getData();
		System.out.println("customerName :"+ customerName);
		System.out.println("customerId :"+ customerId);
		mainclass n = new mainclass(customerName, customerId);
		n.showMenu();
	}
	
	public void checkBalance()
	{
		System.out.println("Your account balance is : " + balanceAmount);
	}
	
	public void withdraw(int withdrawAmount )
 	{
        this.withdrawAmount = -withdrawAmount;
        
        if(balanceAmount!=0 &&  balanceAmount>withdrawAmount)
        {
        	 if(withdrawAmount!=0 )
             {
             	balanceAmount = balanceAmount - withdrawAmount;
             }
        	 else
        	 {
        		 System.out.println("Pleae enter withdraw amount greater than 0");
        	 }
        }
        else
        {
        	System.out.println("Insufficient balance");
        }
        
        System.out.println("Enter the option : ");
        if(s.next().charAt(0)=='A')
        {
      	  checkBalance();
        }
        else if(s.next().charAt(0)=='D')
        {
       	 previousTransactionHistory();
        }
       
	}
	public void deposit(int depositAmount)
	{
		this.depositAmount = depositAmount;
		balanceAmount = balanceAmount + depositAmount;
		System.out.println("Deposited amount: "+ depositAmount);
		
		 System.out.println("Enter the option : ");
		 
         if(s.next().charAt(0)=='A')
         {
        	 System.out.println("Entered into checkbalance");
       	  checkBalance();
         }
         else if(s.next().charAt(0)=='D')
         {
        	 System.out.println("Entered into previous transaction");
        	 previousTransactionHistory();
         }
        	 
	}
	
	public void previousTransactionHistory()
	{
		System.out.println("withdrawAmount : "+withdrawAmount);
		System.out.println("depositAmount : "+depositAmount);
		if(withdrawAmount<0)
		{
			System.out.println("The amount " + withdrawAmount + "has been withdrawn from you account");
		}
		else if(depositAmount<0)
		{
			System.out.println("The amount " + depositAmount + "has been deposited to you account");
	
		}
			
	}

}


class mainclass{
	String customerName;
	int customerId;
	mainclass(String customerName, int customerId)
	{
		 this.customerName = customerName;
		this.customerId = customerId;
	}
	
	
	public void showMenu() {
		
		System.out.println("____________________________________________________________________");
		System.out.println("Welcome : " + customerName);
		System.out.println("Customer id : " + customerId);
System.out.println("/n");
System.out.println("****************************************************************************");

System.out.println("Choose an option");
System.out.println("A. Check Balance");
System.out.println("B. Withdraw Amount");
System.out.println("C. Deposit Amount");
System.out.println("D. Previous Transactionn");
System.out.println("E. Exit");

System.out.println("Enter you option");
Scanner s1 = new Scanner(System.in);
char option = s1.next().charAt(0);
bankingApplication b = new bankingApplication();
System.out.println("option:" + option);
char op;
switch(option)
{

case 'A': b.checkBalance();
          break;
case 'B' :   System.out.println("Enter the amount to withdraw: " );
              b.withdraw(s1.nextInt());
              System.out.println("Enter the option : ");
              if(s1.next().charAt(0)=='A')
              {
            	  b.checkBalance();
              }
              
              break;
case 'C': System.out.println("Enter the amount to deposit: ");             
               b.deposit(s1.nextInt());
               
              
               
               break;
case 'D':  b.previousTransactionHistory();
          break;
case 'E': System.out.println("Thankyou for using our service");
         break;

default: System.out.println("Invalid option!. Please select the valid option");
               
          
}
	}
	
}