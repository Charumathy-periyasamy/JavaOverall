package practice;

public class reverseIntString {
static int a = 183987507;
static String res ;
static String s1 = "deibv";
	public static int reverseInt(int a)
	{
		String s = Integer.toString(a);
		char[] c  = s.toCharArray();
		int size = c.length-1;
		
		for(int i = 0;i<c.length/2;i++)
		{
			System.out.println("i::"+i);
		   char temp = c[i];  //  temp = 1  , 8
		   System.out.println("temp: " + temp);
		   c[i] = c[size]; //  c[i] = 7  , 0
		   System.out.println("c[i] :"+ c[i]);
		   c[size] = temp;  //  c[size] = 1 , 8
		   System.out.println("c[size] : "+ c[size]);
		   size--;               // size = 2 , 1
		   System.out.println("size::"+ size);
		                        // res = 7801 , 7081
		}
		System.out.println(c);
		System.out.println("char is converted to int :: " + Integer.parseInt(String.valueOf(c)));
	return Integer.parseInt(String.valueOf(c));

	}
	
	public static String reverseString(String ss)
	{
		char[] a1 = ss.toCharArray();
		

		int size = a1.length-1;
		System.out.println("size:::"+size); //  4/2 = 2
		
		for(int j = 0; j<a1.length/2; j++)
		{      // deibv
			System.out.println("i::"+j);
			   char temp1 = a1[j];  //  temp = d  , e
			   System.out.println("temp: " + temp1);
			   a1[j] = a1[size]; //  c[i] = v  , b
			   System.out.println("c[i] :"+ a1[j]);
			   a1[size] = temp1;  //  c[size] = d , e
			   System.out.println("c[size] : "+ a1[size]); 
			   size--;               // size = 3 , 2
			   System.out.println("size::"+ size);
			                        // res = veibd  , vbied
		}
		
		System.out.println(a1);
		
		return String.valueOf(a1);
	}
	
	public static void rs()
	
	{
		String s  ="Greati";

		char[] c = s.toCharArray();
		
		int length =s.length();
	char temp;
		for(int i =0;i<=length/2;i++)
		{
			temp = c[i];
			c[i] = c[length-1];
			c[length-1] = temp;
			length--; 
		}
		
		System.out.println(c);
		
	}
	
	public static void sentence()
	
	{
		String sen = "Hello Bye Tell hmm rsdytgiupo";
		int length =sen.length();
	/*	
		char[] c = sen.toCharArray();
		
		
		System.out.println(length);
		char temp;
			for(int i =0;i<=length/2;i++)
			{
				temp = c[i];
				c[i] = c[length-1];
				c[length-1] = temp;
				length--; 
			}
			
			System.out.println(c);
		
		
		System.out.println(c);
		
		*/
	String[] cs =	sen.split(" ");
		
	int sarrlen = cs.length;

	
	String tempstring;
	for(int i =0;i<=sarrlen/2;i++)
	{
		tempstring = cs[i];
		cs[i] = cs[sarrlen-1];
		cs[sarrlen-1] = tempstring;
		sarrlen--; 
	}
	
	for(String f : cs)
	{
		System.out.println(f);
	}
	

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		//reverseInt(a);
		
	//	reverseString(s1);
		
	//	rs();
		sentence();
	}

}
