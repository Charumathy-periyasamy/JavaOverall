package practice;

import java.util.ArrayList;
import java.util.List;

public class wordBreak {

static	List<String> list = new ArrayList<String>();
	static int count = 0;

	static     String s = "Iljove";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		list.add("I");
		list.add("love");
		list.add("coding");
     String[] sarr = s.split("");
     
   boolean res = wobr(list);
    System.out.println(res);

	}
	
	public static boolean wobr(List<String> list)
	{
		StringBuilder sb = new StringBuilder();
		 for(String ls: list)
	     {
	    	 if(s.contains(ls))
	    	 {
	    		 sb.append(ls);
	    		 count++;
	    		 
	    		 if(s.length()==sb.length())
	    		 {
	    		 return true;
	    	 
	    		 }
	    		 else
	    			 {
	    			 continue;
	    			 }
	    			 }
	    	 else
	    	 {
	    		 return false;
	    	 }
	     }
		 return true;
		 
	}

}
