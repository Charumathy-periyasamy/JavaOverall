package practice;

import java.util.Arrays;

public class splitInteger {
	static int a = 7654;
	static int sum = 0;
	static int[] arr;
static	String s ="hai";
	static char[] starr ;
	public static int adddigits(int a)
	{
		while(a>0)
		{
			sum =  sum + a%10;
			a = a/10;
			System.out.println(a);
			
		}
				
		return sum;	
	}
	
	public static char[] splitString(String s)
	{
		starr = s.toCharArray();
	return starr;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int adddigit = adddigits(a);
		System.out.println(adddigit);
		
		char[] c = splitString(s);
		for(char s: c)
		{
			System.out.println("String is splitted into char array::" + s);
		}
		
		System.out.println("converting array into STRING");
		
		String s1 = Arrays.toString(c);
		System.out.println(s1);
		
		

	}

}
