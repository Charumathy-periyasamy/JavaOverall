package practice;

public class printDuplicateCharInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "haiaaa";
		int count = 0;
		
	/// convert it into CharArray 
	// iterate through each and every char
		// count the duplicate elements
		
		char[] charr = s.toCharArray();
	int len = charr.length;                    // haiaaa
	System.out.println("lenght::"+ len);
		for(int i=0;i<charr.length;i++)
		{
			System.out.println("outer loop::");
			System.out.println("i "+charr[i]);
			for(int j=charr.length-1; j<charr.length && j>=0; j--)
			{	
				count++;
				System.out.println("inner loop::");
				System.out.println("j "+charr[j]);
				if(charr[i] ==  charr[j])
				{
					
					System.out.println("Duplicate element is::"+ charr[i]);
				}
			}
		}	
	}
}