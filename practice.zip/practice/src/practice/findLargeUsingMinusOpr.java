package practice;

public class findLargeUsingMinusOpr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int a = 1976;
		int b= 65467;
		int c = 76;
		
		if((a-b)>0)
		{
			if((a-b)-c>0)
{
	System.out.println("c is greatest");
}
			else
			{
				System.out.println("a is greatest");
			}
		}
		else if((a-b)<0)			
		{
			if((b-a)-c>0)
			{
				System.out.println("b is greatest");
			}
			else
			{
				System.out.println("c is greatest");
			}
		}
		
		else if((a-b)==0)
		{
			if(a>c)
			{
				System.out.println("a and b are greatest");	
			}
			else
			{
				System.out.println("c is greatest");
			}
		}
		
	}

}
