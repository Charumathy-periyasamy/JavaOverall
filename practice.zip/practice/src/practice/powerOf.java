package practice;

public class powerOf {

	static int res = 1;
	public static int powerOfANumber(int N, int P)
	{

		
		for(int i =0 ;i<P;i++)  /// imp     i<P		{ 
			if(P==0)
			{
				return 1;
			}
			else if(P==1)
			{
				return N;
			}
			else
			{
				res =  res*N;
				
			
			}
		
		return res;
	}
public static double usingMath(int N, int P)
	
{
	return Math.pow(N, P);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	System.out.println(powerOfANumber(2,9)); 
	System.out.println(usingMath(2,9));
	
	
		
	}

}
