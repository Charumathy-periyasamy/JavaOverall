package practice;

public class addWithoutAddOpr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10;
		int b = 20;
		
		for(int i = 1; i<=20; i++)
		{
			a++;
				
		}
		System.out.println(a);
		
	}

}
