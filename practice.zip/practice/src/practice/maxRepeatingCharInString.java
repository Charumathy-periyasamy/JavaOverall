package practice;

public class maxRepeatingCharInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Programming";
		

	String[] sd = s.split("");
	int length = sd.length;
	int count = 0;
	for(int i = 0; i<=(length-1); i++)
	{ 
		count++;
		for(int j = 1; j>i && !(j>(length-1));j++)
		{
			if (sd[i].contentEquals(sd[j]))
			{
			//	int count = 1;
				
			}
			else
			{
				
			}
		}

	}
		
	}
	

}
