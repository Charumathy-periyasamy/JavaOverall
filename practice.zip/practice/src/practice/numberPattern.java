package practice;

public class numberPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int value = 1;
        
        System.out.println("Here is your pattern :");
         
        for (int i = 1; i <= 5; i++) 
        {
            for (int j = 1; j <= i; j++) 
            {
                System.out.print(value+" ");
                 
                value++;
            }
             
            System.out.println();
        }

		
	}

}
