package practice;

public class factorial {

	/******************************************************************************

    Online Java Compiler.
Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/


// static int n = 4;
static int[] arr = {2,3,4,5,6};
//static int result = 1;
public static void main(String[] args) {
for(int a : arr)
{
int result = 1;
System.out.println("a:" + a);
for(int i=2;i<=a;i++)
{   

result = result*i;
System.out.println("i "+ i);

System.out.println("result "+ result);
}
System.out.println("factorial of "+a+ " is "+  result);
}
}
}



