package practice;

public class pangramString {

	static String s = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
	static String alp = "abcdefghijklmnopqrstuvwxyz";
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	boolean b =	pangram();
		
	if(b)
	{
		System.out.println("The string is pangram");
	}
	else
	{
		System.out.println("The string is not a pangram");
	}
	
}
		 
		
	public static boolean pangram()
	{
		String[] as = alp.split("");
	for(String af: as)
			
		{
			if(s.contains(af))
			{
				continue;
			}
			else
			{
				return false;
			}
		 
		 
		  
		  } 
	return true;
	}
	}


