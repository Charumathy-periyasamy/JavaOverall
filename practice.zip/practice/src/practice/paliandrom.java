package practice;

public class paliandrom {
static String s ="madam";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     //    boolean b =   pal(s);
         palian();
//System.out.println(b);
	}
	
	public static boolean pal(String s)
	{
StringBuffer bf = new StringBuffer();
String reversed = bf.append(s).reverse().toString();

if(s.contentEquals(reversed))
{
	return true;
}
else
	
{
	return false;
}
	}
	
	
public static void palian() {
	String p = "gyijpolkjhgf";
	String[] c = p.split("");
	System.out.println(c.toString());
	
	
int length = p.length();	


int count = -1;
 x:	for(int i=0;i<= length/2; i++)
	{
	 
	

	System.out.println("valueof i : " + i);
	
	for(int j = (length-1)-i; j>=i;j-- )
		{
		
			System.out.println("valueof j : " + j);
			if(c[i].contentEquals(c[j]))
			{
				count++;
				System.out.println("count "+ count);
					System.out.println("c[i]"+c[i]);
					System.out.println("c[j]"+c[j]);
                   continue x;
			}
			else 
			{
			continue;	
			}

			
			
		}
	


}
 
 if(count == length/2)
	{
		System.out.println("the string is a palindrom");
	}
	else {
		System.out.println("the string is not a palindrom");
	}
	}
 
	}



//  The compare(char x, char y) method of character class returns

//a value 0 if x==y
//a value less than 0 if x<y.
//a value greater than 0 if x>y.