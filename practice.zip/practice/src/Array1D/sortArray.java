package Array1D;

public class sortArray {
	
	
	public static void sortInAscendingOrder()
	{
		int[] arr1 = new int[] {34,64,8,24};
		int temp;
		
		for(int i = 0; i<=arr1.length-1;i++)
		{
			for(int j=arr1.length-1;j>i ;j--)
			{
				if(arr1[i]>arr1[j])
				{
					temp = arr1[i];
					arr1[i] = arr1[j];
					arr1[j] = temp;
				}
			}
		}
		
	for(int f : arr1)
	{
		System.out.println(f);
	}
	
	}
	
	public static void sortInDescendingOrder()
	{
		
			int[] arr1 = new int[] {34,64,8,24,34};
			int temp;
			
			for(int i = 0; i<=arr1.length-1;i++)
			{
				for(int j=arr1.length-1;j>i ;j--)
				{
					if(arr1[i]<arr1[j])
					{
						temp = arr1[i];
						arr1[i] = arr1[j];
						arr1[j] = temp;
					}
				}
			}
			
		for(int f : arr1)
		{
			System.out.println(f);
		}
		
	}
	
	public void arraysSort()
	{
	
		
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		sortInAscendingOrder();	
		sortInDescendingOrder();
	}

}
