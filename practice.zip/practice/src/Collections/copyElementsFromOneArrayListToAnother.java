package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class copyElementsFromOneArrayListToAnother {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		List<String> list = new ArrayList<String>();
		ArrayList<String> list1 = new ArrayList<String>();
		
		list.add("hello");
		list.add("hai");
		list.add("Bye");
		list.add("bye");
		
// using add all() of LIST		
		list1.addAll(list);
		
		System.out.println("list1::"+ list1);
		
		System.out.println("list::"+ list);
	
// Using Copy() method in collections calss
		
		Collections.copy(list1, list);
		
		System.out.println("list1::"+ list1);
		
	}

}
