package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class maxValueInArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = new ArrayList<Integer>();
		List<Integer> list1 = new ArrayList<Integer>();
		int count =0;
		list.add(60);  
		list.add(2);   
		list.add(765);
		list.add(765);
		list.add(8);
		
		list1.add(86554);
		
				
	System.out.println(Collections.max(list));	
	
	//15,7,22,5,10
   x :	for(int i =0;i<list.size();i++)
	{
		System.out.println("i::"+i);
		
		for(int j = list.size()-1;j<list.size();j--)
		{			
			System.out.println("j::"+j);			
			if(list.get(i)>list.get(j))  //6>8
			{
			//	System.out.println("MAX::"+list.get(i));
			//	System.out.println("MIN::"+list.get(j));
				count++;
				System.out.println("count::"+count);
			}
			else if(list.get(i)<list.get(j))  // 6<8
			{
			//	System.out.println("MAX::"+list.get(j));
			//	System.out.println("MIN::"+list.get(i));
				break;
			}
			
			else if(list.get(i)==list.get(j))
			{
			//	System.out.println("equal");
				count++;
			}
			
			if(count == list.size()-1)
			{
				System.out.println("maximun number in the list is : " + list.get(i));
				break x;
				
			}
		}
		
		
	}
	
	
	
		
		
	//	System.out.println(Collections.max(list, list1));
		
	}

}
