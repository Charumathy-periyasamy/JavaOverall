package Collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class swapArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = new ArrayList<Integer>();
		List<Integer> list1 = new ArrayList<Integer>();
		int count =0;
		list.add(60);  
		list.add(2);   
		list1.add(2);
		list1.add(765);
		list1.add(0);
		
		System.out.println("Before"+list);
		Collections.swap(list, 0, 1);
		
		System.out.println("Before"+list);
		
	}

}
