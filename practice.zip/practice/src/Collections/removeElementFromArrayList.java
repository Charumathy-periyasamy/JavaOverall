package Collections;

import java.util.ArrayList;
import java.util.List;

public class removeElementFromArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	List<String> list = new ArrayList<String>();
	list.add("hello");
	list.add("hai");
	list.add("Bye");
	list.add("bye");
	
// remove directly
	
	list.remove("bye");
	list.remove(0);
	
	System.out.println(list);
		
	// remove while looping through the list
	
	for(int i=0;i<=list.size();i++)
	{
		if(i==1)
		{
			list.remove(i);
			System.out.println(list);
		}
	}
	
	list.add("uiah");
	list.add("uytyu");
	
	for(String f : list)
	{
		if(f=="uytyu")
		{
			list.remove(f);
			System.out.println(list);
		}
	}
	
	
	
	}

}
