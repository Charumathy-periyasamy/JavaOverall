package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.swing.event.ListSelectionEvent;

public class SortingArraylist implements Iterable{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list1 = new ArrayList<>();
		List<String> list2 = new ArrayList<>();
		List<Integer> list3 = new ArrayList<>();
		List<Integer> list4 = new ArrayList<>();
		List<Integer> list5 = new ArrayList<>(list4.size());
		List<String> Stringlist = new ArrayList<>( Arrays.asList("v","t","c"));
		
	//	List<String> Stringlist = new ArrayList<>( List.of("a","b","c"));
		List<Integer> list7 = new ArrayList<>();
		
		list1.add(9);
		list1.add(8);
		list1.add(7);
		list1.add(6);
		list2.add("hai");
		list2.add("ahlg");
		list7.add(34);
		list7.add(98);
		list7.add(4);
		
		
		System.out.println("Before"+list1);

// three ways to sort the ArrayList
// 1. using Collection.sort		
		Collections.sort(list1);
		
		
		System.out.println("using Collections.sort() --> after::" + list1);
		
// 2. using ArrayList.sort()	
		
		System.out.println("before"+list2);	
	list2.sort(Comparator.naturalOrder());
	System.out.println("after"+list2);
	
// 3. sort using custom methods
	
	System.out.println("sorting String");
	
// sorting int
	
	for (int i = 0; i < list7.size(); i++) {

        for (int j = list7.size() - 1; j > i; j--) {
            if (list7.get(i) > list7.get(j)) {

                int tmp = list7.get(i);
                list7.set(i,list7.get(j)) ;
                list7.set(j,tmp);
                

            }

        }

    }
    for (int i: list7) {
        System.out.println(i);
    }
    
  // sorting array
    
    int[]  in = {3,98,1};
    
    for (int i = 0; i < in.length; i++) {

        for (int j = in.length - 1; j > i; j--) {
            if (in[i]>in[j]) {

                int temp = in[i];
                in[i] = in[j];
                in[j] = temp;

            }

        }

    }
    for (int f: in) {
        System.out.println(f);
    }
    
    
// sorting an string of array
    String[] st = {"iz","iuyuiu","qouj","a"};
    for (int i = 0; i < in.length; i++) {

        for (int j = st.length - 1; j > i; j--) {
            if (st[i].compareTo(st[j])>0) {

                String temp = st[i];
                st[i] = st[j];
                st[j] = temp;

            }

        }

    }
    for (String s: st) {
        System.out.println(s);
    }
    
	
// reversing an arraylist
	
// using normal loop	
	System.out.println("using normal for loop");
	System.out.println("size of list1"+ list1.size());
	
	for(int i=list1.size()-1;i<=list1.size() && i>=0;i--)
	{
		list3.add(list1.get(i));
		System.out.println(list3);
	}
	System.out.println("list3-- reversed using for loop  "+ list3);
	
// using for each
	
	ListIterator<Integer> it = list3.listIterator(list3.size());
  
 while(it.hasPrevious())
 {
	System.out.println("using iterator");
	list4.add(it.previous());
	System.out.println(list4);
 }
 
 //  reverse using inbuilt methods
 
 System.out.println("reverse using collection inbuilt method");

	Collections.reverse(list4);
	
	System.out.println(list4);
	
// searching element in arraylist
	
System.out.println(list4.contains(8));

// get sublist of list4

System.out.println("get sublist of list4 " );

System.out.println(list4.subList(0, list4.size()-2));

/// copy elements from one arraylist ot another

System.out.println("list5 before copy: "+ list5);
//Collections.copy(list5, list4);

System.out.println("list5 after copy: "+ list5);
	
ArrayList<Integer> list6 = new ArrayList<Integer>(list4);

System.out.println("list6 after copy: "+ list6);
	}

	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return null;
	}
}
