package hackerRank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class sumlist {

	public static List<Integer> list = new ArrayList<>(Arrays.asList(1,2,3,4,5));
	
	
	
	public static void main(String[] args)
	

	{
		int max = maxInList(list);

		
	}
	
	public static int maxInList(List<Integer> list1)    //1,10,5,4,5
	{
		int count = 0;
		int res = 0 ;
  x:		for(int k : list1)
		{
			for(int i = list1.size()-1; i<list1.size();i-- )
			{
				if(k<list.get(i))     //1<5  // 1<4  // 1<5 // 1<10    
				{
					count ++;
					break;
				}
				else if( k == list.get(i) )  // 1==1
				{
					if(count == list.size()-1)
					{
						break x;
					}
					continue;
				}
				else if( k > list.get(i))
				{
					continue;
				}
			}
			
			res = k;
		}
		return res;
		
	}
}

/*
Given five positive integers, find the minimum and maximum values that can be calculated by summing exactly four of the five integers. 
Then print the respective minimum and maximum values as a single line of two space-separated long integers.

Example
 arr = [1, 2, 3,4 5];
The minimum sum is [1+2+3+4]=16 and the maximum sum is [2+3+4+5] =26 . The function prints   16 26

*/
