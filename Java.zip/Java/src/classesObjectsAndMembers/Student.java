package classesObjectsAndMembers;

public class Student {

	int id ;
	byte age ;
	short rank;
	long phone ;
	char grade;
	int tutionfee = 10000;
	int internationalFee = 5000;
	boolean international;
	String name;
static	int count; 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student s1 = new Student();
Student s2 = new Student();
Student s3 = new Student();



s1.name = "John";
s1.id = 10;
s1.age = 22;
s1.rank = 3;
s1.phone = 6776578;
s1.international = true;

s1.Compute();


s2.name = "Raj";
s2.id = 11;
s2.age = 22;
s2.rank = 2;
s2.phone = 55776578;
s2.international = false;

s2.Compute();

s3.name = "Anita";
s3.id = 11;
s3.age = 22;
s3.rank = 2;
s3.phone = 15776578;
s3.international = true;


s3.Compute();

s1.typeCasting();
	}

	public void Compute()
	{
		count = count+1;
		System.out.println("count:  " + count);
		if(international==true)
		{   
			tutionfee = tutionfee + internationalFee;
			System.out.println("tutionfee: " +tutionfee);
			
			
		  
		}
		else
		{
			System.out.println("tutionfee: " + tutionfee);
		}
		
		System.out.println("name " + name);
		System.out.println("id: "  + id);
		System.out.println("age: "  + age);
		System.out.println("rank: "  + rank);
		System.out.println("phone: "  + phone);
		System.out.println("grade" + grade);
		
		
	   
	   byte minValue = Byte.MIN_VALUE;
	   
	   byte maxValue = Byte.MAX_VALUE;
	   
	   System.out.println(minValue);
	   System.out.println(maxValue);
	   
	}
	
	public void typeCasting()
	{
		long y = 42;
		int x = (int)y;
		System.out.println("y: " + y);
		System.out.println("x: " + x);
		
	//information loss due to out of range assignment
		 byte b = (byte) 123456;
		 System.out.println("byte b: "+ b );
		 
	//Truncation
		 int c = (int) 0.99;
		 System.out.println("int c: " + c);
		 
// implicit cast int to long
		 y = x; 
		 System.out.println("int to long : "+ y);
		 
// implicit char to int
		 
		 int f = 'A';
		 System.out.println("char to int : " +f );
		 
		 
// explicit cast byte to char
		 
		 byte by = 65;
		 char cf = (char)by;  // here byte will get convert to int [implicit] and then int will get convert to char[explicit]
		 System.out.println("char to int : "+ cf);
		 
	}
	
}
