package classesObjectsAndMembers;

public class CurrencyConverter {

	int rupee = 63;
	int dirham  = 3;
	int real  = 3;
	int chilean_peso = 595;
	int mexican_peso = 18;  
	int _yen = 107 ;
	int $australian = 2;
	int dollar;
	int Rupee = 63 ;
	
	public static void main(String[] args) {
		CurrencyConverter cc = new CurrencyConverter();
		cc.printCurrencies();
		
		
	}

	public void printCurrencies()
	{
		System.out.println("rupee: " + "63");
		System.out.println("dirham: " + "3");
		System.out.println("real: " + "3");
		System.out.println("chilean_peso: " + "595");
		System.out.println("mexican_peso: " + "18");
		System.out.println("_yen: " + "107");
		System.out.println("$australian: " + "2");
		System.out.println("Rupee: " + "63");
	}
}
