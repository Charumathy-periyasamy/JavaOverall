package Enum;

public enum BookGenere {
	
	BIOGRAPHY,
	HORROR;
	
	public static void main(String args[])
	{
		System.out.println(BookGenere.BIOGRAPHY);
		System.out.println(BookGenere.HORROR);
		System.out.println(BookGenere.values());
	//	System.out.println(BookGenere.valueOf(null));
		
		
		for(BookGenere bookgenere : BookGenere.values())
			
		{
			System.out.println("bookgenere :" + bookgenere);
			System.out.println(bookgenere.compareTo(BookGenere.HORROR));
			System.out.println(bookgenere.equals(BookGenere.HORROR));
			System.out.println(bookgenere.name());
			System.err.println(bookgenere.ordinal());
			System.out.println(bookgenere.toString());
			System.out.println(bookgenere.getDeclaringClass());
			System.out.println(bookgenere.valueOf("HORROR"));
		}
	}

}
