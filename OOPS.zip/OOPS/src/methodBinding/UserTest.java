package methodBinding;


public class UserTest {

	public static void main(String[] args) {
		
	User us = new Staff();
	us.instancemethod(10);// here we are passing int parametere, what we will think is the staff class has the excact match
	                      // so method in staff will get invoke.  but what exactly  will happen is that the method in user class with
	                      // double as parameter type will get invoke.
	                       // why??????  :: because compiler will try to find the exact match in the User class first but in user clss
	                       // the same method is present with the double has parameter but it is compatible so the compiler will insist JVM to invoke 
	                       // the method with parameter type as double and in Runtime time  JVM will search for the same in staff class, in staff class
	                    // the same method is present in the parameter type as int which is not-compatible then it will move up in the
	                    // inheritance tree and search in User class and invoke it.
	
	}

}
