package methodBinding;

import methodoverriddingandsuperkeyword.Review;

public class User {
public int id =2;
	
	public Review postAReview(String reviewText)
	{
		System.out.println("Userrf: postAReview");
		
		return new Review(reviewText);
				
	}
	public void instancemethod(double d)
	{
		System.out.println("User: instance method");
	}
}
