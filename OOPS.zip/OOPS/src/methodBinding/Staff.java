package methodBinding;



public class Staff extends User{

	public int id =1;
	
	
	 public void instancemethod(int a) {
	  
		 
		 System.out.println("staff: instance method");
	  }
	 

	
}
