package Abstract;

public class concretesubclass extends abstractsubclass {

	@Override
	protected void test3() {
		// TODO Auto-generated method stub
		
		System.out.println("test3");
		
	}

	@Override
	void test2() {
		// TODO Auto-generated method stub
		System.out.println("test2");
		
	}
	 void s()
	  {
		  System.out.println("concrete method inside the abstract sub super class");
	  }
	
	 void m1()
		{
		      System.out.println("m1 inside the sub class");	
		}
	 public void m()
		{
				System.out.println("inside concrete method in concretesubclass");
		}
	 void ti()
	 {
		System.out.println("kahgad"); 
	 }
	 
	public static void main(String[] args)
	{
	
		
		  concretesubclass c = new concretesubclass(); 
		  c.test1();
		  c.test2(); 
		  c.test3();
		  abstractsubclass a = new concretesubclass(); 
		  a.m();
		  
		  ((concretesubclass) a).ti();
		  concrete cn = new concrete(); 
		  cn.m();
		  
		  
		  concretesubclass ab = new concretesubclass(); // if i use super type as
		                                            //  reference type then it will not allow the user
		                           // access additonal methods which is declared in subclass.
	
		abstractsubclass ac = new concretesubclass();
		ac.m2();   // this method  invoke willthe m2 in super class.. that m2 method having the statement this.m1 --- which will
		             // invoke the m1 method in sub class as the method invocation statement is provided in sublass  
		
	
		
		
	//	abstractsuperclass ab = new abstractsuperclass();  // will provide the comipler error as abstract class cannot be instantiated
	
	
	}


}




/*
 * public abstract class A { private int x; A(int x){
 * System.out.println("Value of x: " +x); } abstract void m1(int x, double y); }
 * public class B extends A { private int y; B(int y){ super(10);
 * System.out.println("Value of y: " +y); } void m1(int x, double y){
 * System.out.println("One"); } void m2(){ System.out.println("Two"); this.m1(5,
 * 10.50); } } public class C extends B { C(){ super(30); } void m1(int x,
 * double y){ super.m1(10, 15.15); System.out.println("Three"); } } public class
 * Test { public static void main(String[] args){ B b = new C(); b.m1(10,
 * 20.50); b.m2(); }
 */