package Abstract;

public class concrete extends concretesubclass {
	@Override
	void test2()
	{
		System.out.println("under concrete class");
	}

	public void m()
	{
			System.out.println("inside concrete method in subclass");
	}
	
}
