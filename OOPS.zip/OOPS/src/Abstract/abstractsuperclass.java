package Abstract;

 abstract public class abstractsuperclass  {
	
 private int a = 10;
	static int f = 8;
	public int t =0;
	
	
	   abstract void test1();  // an abstract method must be declared as abstract in abstrace class
//	  void test2(); // will show compiler error
	  abstract void test2();
	  
	

}
