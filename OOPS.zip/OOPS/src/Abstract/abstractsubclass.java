package Abstract;

abstract class abstractsubclass extends abstractsuperclass {
	
	@Override
	void test1()

	{
		System.out.println("test1");
		System.out.println("public varibale of abstract super class:"+t);
		
		System.out.println("static variable of abstract super class: " + f);
	//	System.out.println(a);
	}
	
	abstract  void test3();
	 // abstract methods are protected by default
	
	void m1()
	{
	System.out.println("m1 inside the abstract sub class");	
	}
	void m2()
	  {
		  System.out.println("concrete method inside the abstract sub class");
		  this.m1();
	  }
	 public void m()
		{
				System.out.println("inside concrete method in abstractsubclass");
		}
	 
	
	
}
