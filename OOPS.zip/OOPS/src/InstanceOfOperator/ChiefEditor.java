package InstanceOfOperator;

public class ChiefEditor extends Editor{
	
	public void notstaffalso() {
		 
		System.out.println("not a staff");
	}

}
