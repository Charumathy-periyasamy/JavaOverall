package InstanceOfOperator;

public class Staff {
	
	public void work()
	{
		System.out.println("inside work of staff");
	}
	public void common()
	{
		System.out.println("common to staff class");
	}

}
