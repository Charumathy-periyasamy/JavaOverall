package InstanceOfOperator;

public class InstanceOf {
	
	public static void castng() {
		/*
		 * Editor e = new Editor(); e.astaff(); e.common();
		 */
		Staff s = new Editor();  // here implicit casting happened means Editor is assigned to the Staff
		s.common(); // we can access only the methods common to super and subclass as implicit casting implemented
		s.work();   // we can also able to access the methods in super class .. method specific to subclass are not accessible
	//	((Editor)s).notstaffalso(); // will show compilation error.. as notstaffalso() is a method of Chiefeditor
		
		  ((Editor)s).astaff();
		  
		  
	//	  Editor e = new Editor();
//		  ((ChiefEditor) e).notstaffalso(); // showing CLASSCASTEXCEPTION - means Editor is not only the cheifeditor it can be somthig else too

		
	    
	}
 public static void InstanceOf(Staff s)
 {
//	s.common();
//	s.work();
	if(s instanceof Editor)
	{
	((Editor) s).astaff(); // showing runtime error as Staff is not only the editor it can be something else to
//	((Editor) s).notstaffalso(); // not correct as per the rule of method invocation // the jvm will search from the the bottom
	}
	else if(s instanceof ChiefEditor)
	{
		((ChiefEditor) s).notstaffalso();
	//	((ChiefEditor) s).astaff();  -- correct
	}
	else
	{
		System.out.println("the object 's' not instance of the respective object");
	}
	 
 }
	public static void main(String[] args) {
	
//   castng();
   InstanceOf(new Staff());
  InstanceOf(new Editor());
   InstanceOf(new ChiefEditor());
   
   

	}
	

}
