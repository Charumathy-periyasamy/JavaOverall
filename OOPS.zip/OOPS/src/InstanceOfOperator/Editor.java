package InstanceOfOperator;

public class Editor extends Staff {
	
	public void astaff()
	{
		System.out.println("it is the instance (subclass) of staff");
	}
	public void common()
	{
		System.out.println("common to staff and editor class");
	}

}
