package interfacepractice1;

public interface B {

	String B = "interfaceB";
	String getdatafromconcreteB();
	void foo();

}