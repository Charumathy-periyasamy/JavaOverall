package interfacepractice1;

public class Main {

	public static void main(String[] args) {
		
		/*
		 * A a = new Concreteclass();
		 *  a.getdata();
		 */
		
		A a = new Concreteclass();
		a.foo();
		
		B b = new Concreteclass();
		b.foo();
		
		
		/*
		 * Concreteclass c = new Concreteclass();
		 * 
		 * 
		 * System.out.println(c.getdatafromconcreteA());
		 * System.out.println(c.getdatafromconcreteB());
		 */  
		 
		
		
		/*
		 * SubclassOfConcreteclass su = new SubclassOfConcreteclass();
		 * 
		 * System.out.println(su.getdatafromconcreteA());
		 * System.out.println(su.getdatafromconcreteB());
		 */
		 
      
		
		
		  Concreteclass cc = new SubclassOfConcreteclass();
		  
		  System.out.println(cc.getdatafromconcreteA());
		  System.out.println(cc.getdatafromconcreteB());
		 
		 
		
		
	}
	

}
