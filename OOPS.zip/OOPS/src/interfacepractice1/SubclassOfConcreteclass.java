package interfacepractice1;

public class SubclassOfConcreteclass extends Concreteclass {

	/*
	 * public String getdatafromconcreteB() { return "b" + B; }
	 */
}
