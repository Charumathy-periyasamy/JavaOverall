package interfacepractice1;

public abstract class Abstract extends SubclassofAbrstract implements A {
	
	
	/*
	 * public String getdatafromconcreteA() { return "a" + A.A; }
	 * 
	 * 
	 * 
	 * public String getdatafromconcreteB() { return "b" + B.B; }
	 */
}
