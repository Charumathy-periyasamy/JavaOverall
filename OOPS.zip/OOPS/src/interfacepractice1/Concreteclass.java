package interfacepractice1;

public class Concreteclass extends Abstract implements B {

	public void getdata()
	{
		System.out.println("inside the concrete class");
	}

	@Override
	public void foo() {
		// TODO Auto-generated method stub
		
		System.out.println("for interface A");
		
	}

	
	

	
	/*
	 * public String getdatafromconcreteA() { return "a" + A; }
	 */
	/*
	 * public String getdatafromconcreteB() { return "b" + B; }
	 */

		
}
// note the subclass should implement all the abstract methods declared in main interface if some of the methods not implemented in subclass
// then it can be implemented in the subclass of the subclass.