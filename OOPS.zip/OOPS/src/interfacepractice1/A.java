package interfacepractice1;

public interface A {

	String A = "interfaceA";
	void getdata();
	
	
	String getdatafromconcreteA();
	void foo();
	
}
