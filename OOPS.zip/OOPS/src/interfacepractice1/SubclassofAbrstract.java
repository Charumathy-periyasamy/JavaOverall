package interfacepractice1;

public abstract class SubclassofAbrstract  {

	public String getdatafromconcreteB()
	{
		return "b" + B.B;
	}
	public String getdatafromconcreteA()
	{
		
		return "a" + A.A;
	}
}
