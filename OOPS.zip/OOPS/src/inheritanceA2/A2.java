package inheritanceA2;

public class A2 {

}
