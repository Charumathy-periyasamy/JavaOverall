package inheritanceA2;

import inhertanceA1.A1;

//import inhertanceA1;

public class B2 {

	public static void main(String[] args) { 
		
	//	System.out.println("A1.privatemember : " + A1.privatemember );
		
	
	//	System.out.println("A1.defaultmember:  " + A1.defaultmember);
	//	System.out.println("C1.defaultmember:  " + C1.defaultmember);
		
		
	//	System.out.println("A1.protected member :" + A1.protectedmember);  // B2 is not a subclass of A1 so protected member of A1 will not be visible to B2
	//	System.out.println("C1.protected member :" + C1.protectedmember);
//		System.out.println("C2.protected member :" + C2.protectedmember); // C2 is the subclass of A1 but still through C2 B2 will not be able to access the
		                                                // protected member of A1 as B2 is not belongs to same package
		
		System.out.println("A1.public member : " + A1.publicmember );
	//	System.out.println("C1.public member : " + C1.publicmember );
		
		
	//	System.out.println("protected member :" + protectedmember);
	}

	
}
