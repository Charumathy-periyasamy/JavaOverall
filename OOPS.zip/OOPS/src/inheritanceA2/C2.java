package inheritanceA2;

import inhertanceA1.A1;

public class C2 extends A1{
	
	public static void main(String[] args) { 
	
//	System.out.println("privatemember : " + privatemember );
//	System.out.println("defaultmember:  " + defaultmember);  // defaultmember of A1 will not be visible to c2 as default memeber is accessoible only to the class of same package
	System.out.println("public member : " + publicmember );
	System.out.println("protected member :" + protectedmember);

	// protected members can be accessible by any subclass and the sub-class need not to be in the same package
	
}

}