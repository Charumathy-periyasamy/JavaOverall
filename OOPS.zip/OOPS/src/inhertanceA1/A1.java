package inhertanceA1;

public class A1 {

	
	static private int privatemember = 1;
	static int defaultmember = 2;  // will behave as default
	static public int publicmember = 3;
	static protected int protectedmember = 4;
	
	/*
	 * public static void main(String[] args) { // TODO Auto-generated method stub
	 * 
	 * }
	 */

}
