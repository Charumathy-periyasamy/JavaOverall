package inhertanceA1;

public class C1 extends A1 {
	
	// inherited members are directly accessible
	
	public static void main(String[] args) { 
		
	//	System.out.println("privatemember : " + privatemember );  // privatemember of one class will be visible to another class will show compilation error
		System.out.println("defaultmember:  " + defaultmember);
		System.out.println("public member : " + publicmember );
		System.out.println("protected member :" + protectedmember);
	//	System.out.println();
		 
		  }

}
