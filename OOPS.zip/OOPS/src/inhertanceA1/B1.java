package inhertanceA1;

import inheritanceA2.C2;

public class B1 {
	public static void main(String[] args) { 
		
	//	System.out.println("A1.privatemember : " + A1.privatemember ); // // privatemember of one class will be visible to another class will show compilation error
		
	
		System.out.println("A1.defaultmember:  " + A1.defaultmember); 
		System.out.println("C1.defaultmember:  " + C1.defaultmember);
		
		
		System.out.println("A1.protected member :" + A1.protectedmember);
		System.out.println("C1.protected member :" + C1.protectedmember);
		System.out.println("C2.protected member :" + C2.protectedmember);
		
		System.out.println("A1.public member : " + A1.publicmember );
		System.out.println("C1.public member : " + C1.publicmember );
		
		
		//System.out.println("protected member :" + protectedmember);
	}

}
