package methodoverriddingandsuperkeyword;

public class Staff extends User {
	
	public int id =1;
	
// Rule 1: overridding method cannot be less accessible:	
	
	public Review postAReview(String revieewText)  // this method is overridding the postAReview() in User class
	                           // if access type of overridding method is changed to the access level less than the access level of the super type then we will get compiler error
	{
		
		 System.out.println("staff: postAReview"); 
		 //return new Review(revieewText); // printing Staff: post a review
		 
		return super.postAReview(revieewText);  // printing user: post a review.
		
		
	}
	
	// super keyword cannot be used in static method:
	
	/*
	 * public static void staticMethod() { super.postAReview(); }
	 */
	
	// super keyword is also used to access the hidden fields in super class
	
	public void printId()
	{
		System.out.println("id:" + id);
		System.out.println("super.id:"+ super.id);
	}
}
