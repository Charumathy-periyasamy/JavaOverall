package methodoverriddingandsuperkeyword;

public class Review {
	
	private String reviewText;
	private boolean approved;
	
	
	public Review (String reviewText)
	{
		System.out.println("entered into the constructor");
		this.reviewText = reviewText;
		
	}
	public boolean isApproved()
	{
		return approved;
	}
	
	public void setApproved(boolean approved)
	{
		this.approved= approved;
	}
	

}
