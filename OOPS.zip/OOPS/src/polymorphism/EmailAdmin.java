package polymorphism;

public class EmailAdmin extends Staff {
	
	public void handleEmailCampaign()
	{
		System.out.println("handleEmailCampaign: EmailAdmin");
	}

}
