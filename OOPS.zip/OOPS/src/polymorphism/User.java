package polymorphism;

public class User {
 public void printusertype()
 {
	 System.out.println("printusertype : user"); 
 }
	
	public void saveWebLink()
	
	{
		System.out.println("saveweblink: user");
		postAReview();
	}
	public void saveMovie()
	{
		System.out.println("savemovie: user");
	}
	public void rateBookMark()
	{
		System.out.println("ratebookmark: user");
	}
	
	public void saveBook()
	{
		System.out.println("savebook: user");
	}
	
	public void postAReview()
	{
		System.out.println("postAReview: user");
	}
	
public void testuser()
	
	{
		System.out.println("testuser");
	}
	
}
