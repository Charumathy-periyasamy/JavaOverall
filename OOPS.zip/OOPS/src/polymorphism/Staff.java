package polymorphism;

public class Staff extends User {

	public void postAReview()   // common method for User and Staff
	{
		System.out.println("postAReview: staff");
	}
	
	public void printusertype()   // common method for User and Staff
	 {
		 System.out.println("staff"); 
	 }
	
public void teststaff()
	
	{
		System.out.println("teststaff");
	}

public void testss()
{
System.out.println("Specific public class in staff");	
}


}
