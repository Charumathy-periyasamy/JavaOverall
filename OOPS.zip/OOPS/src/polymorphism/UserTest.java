package polymorphism;


public class UserTest {

	public void printtype(User u) {  // why we have one common method with parameter as super type -- meaning no need to create a separate method for calling methods in sub class
	    u.printusertype();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

// part 1 == checking -- subclass can be assigned to the reference type of super class
		
		User user = new User();
		User Staff = new Staff();
		User editor = new Editor();
		User ched = new ChiefEditor();
		ChiefEditor ChiefEditor = new ChiefEditor();
		UserTest usertest = new UserTest();
	ChiefEditor.rejectReview();
	ChiefEditor.updateHomePage();
		usertest.printtype(user);
		usertest.printtype(Staff);
		usertest.printtype(editor);
	Staff.testuser();

	
	
	if(ched instanceof ChiefEditor)
	{
		System.out.println("inside the instanceof");
		((Staff)ched).testss();
	}
// part 2 -- method invocation
		
		editor.postAReview();
		editor.saveWebLink(); // with editor object saveweblink() of user and postareview() of staff is invoked  because JVM will start to search form user 
		editor.saveWebLink();  // will invoke saveweblink() of user and postareview() of user is invoked because JVM will start to search form editor 
		ChiefEditor.rejectReview();
		
	}
	

}

/* note difference between:

Superclass obj = new Subclass();   -- only public methods of superclass is accessible 
Subclass objs = new Subclass();   -- - public methods of super and subclass are accessible


*/