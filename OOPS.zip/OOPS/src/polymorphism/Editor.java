package polymorphism;

public class Editor extends Staff {

	
	public void approveReview()  // common for user, staff, editor
	{
		System.out.println("approveReview: Editor");
	}
	
	public void rejectReview()
	{
		System.out.println("rejectReview: Editor");
	}
	public void printusertype()   // common for user, staff, editor
	 {
		 System.out.println("editor"); 
	 }
}

