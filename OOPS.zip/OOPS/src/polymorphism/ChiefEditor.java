package polymorphism;

public class ChiefEditor extends Editor{

	
	public void updateHomePage()
	{
		System.out.println("updateHomepage: chiefeditor");
	}
	
	  public void rejectReview() { System.out.println("chiefeditor: ChiefEditor"); }
	 

	  private void chi()
	  {
		  
	  }
}