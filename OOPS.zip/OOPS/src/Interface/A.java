package Interface;

public interface A {
	
//	int VAL1;// compilation error a static final variable need to be initialized
	int VAL = 6;
//	void foo();
	void bar(); // no need to provide these methods as public and abstract as by default methods in interface are public and abstract
	void foobar();
	void foo(); 
	 
	 
}
