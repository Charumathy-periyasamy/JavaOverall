package Interface;

// x is the subclass  the compiler will force to implement the abstract methods in the super interface
// he subclass X need not to implement as AbstractA in intern extending A
public class X extends AbstractA implements  A,C, B{

	
	
	  public void foo() { System.out.println("X : Foo() for Interface A"); } 
	  
	 /* 
	 * // System.out.println("VAL: " + VAL); // it is varible initialized in the
	 * super class // if we try to print only VAL if two variables has been provided
	 * with the same name // in A and B then the compiler will show error.
	 * System.out.println("VAL: " + A.VAL); System.out.println("VAL: " + B.VAL);
	 * 
	 * System.out.println("VAL: " + VAL1); }
	 */
		
		/*
		 * public void foobar() { System.out.println("X: Foobar()"); }
		 */

			/*
			 * public void bar() { System.out.println("X: bar"); }
			 */
	 
	  }

// Notes: it is mandatory to provide the abstract method (in super interface) of all the methods implemented in subinterface