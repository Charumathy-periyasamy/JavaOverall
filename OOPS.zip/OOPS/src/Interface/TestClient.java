package Interface;

public class TestClient {

	public static int getVal()
	{
		return 42;
	}
	
	public static void main(String[] args) {
		
	//	A a = new A();    //  throwing compilation error as we have instaniated interface , interfaces cannot be instaniated as it will not have any state.
//		A a = new X();   // interface can be used as a reference type  but not the object type
		//a.foo();   // will throw compilartion error as we haven't haven't provided any implementation for foo()
	//	a.foo(); 
	//	a.bar();
		
		A a = new X();
		a.foo();
		a.bar();
		 a.foobar();
		 
			
			  B b = new X();
			  b.foo();
			 

	}

}
