package Interface;

public interface B {
	
	void foo();
     int VAL = 29;
     int VAL1 = TestClient.getVal();
}
