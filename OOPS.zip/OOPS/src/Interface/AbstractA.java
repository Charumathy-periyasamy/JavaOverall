package Interface;

// this is the subclass of the interface A

public abstract class AbstractA {

	
	
	  public void bar() { // in abstract it is not necessary to prov implementation
	//  for any of the inherited abstract method.
	  
	  System.out.println("AbstractA: bar"); }
	  
	 public void foo()
	 {
		 System.out.println("for interface B");
	 }
	
		  public void foobar() 
		  { System.out.println("abstractA : Foobar()"); }
		 
}
