package string;

import java.util.Arrays;
import java.util.Collections;

public class compareto {

	 static String string5 ;
		public static void main(String[] args) {
		
		String string1 = "hello";
		String string2 = "world";
		String string3 = "hello";
		String string4 = "uigiuha";
		
		System.out.println(string1.compareTo(string2));
//		System.out.println(string5.compareTo(string2)); // string5 is NULL --> Will throw NullPointerException
		System.out.println(string1.compareTo("hea"));
		System.out.println(string1.compareTo(" "));
		System.out.println(" ".compareTo(string2));
		System.out.println(string1.compareTo(""));
		System.out.println(string1.compareTo("-1"));
		
		
		String[] s = {"a","j","b"};
		
// ascending order	
	
Arrays.sort(s);
System.out.println(Arrays.toString(s));
		
// descending order
		
		Arrays.sort(s, Collections.reverseOrder());
		System.out.println(Arrays.toString(s));
		}

}
