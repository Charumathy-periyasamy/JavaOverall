package string;

public class substring {

	

	


	    void method(String s)
	    {
	        System.out.println("inside method: " +s);
	    }
		public static void main(String[] args) {
		//	System.out.println("Hello World");
			String s = "javatttpoint";
			substring m = new substring();
		m.method(s.substring(5));
		

		System.out.println(s.substring(5));
		System.out.println(s.substring(0,9));
		System.out.println(s.substring(1,1)); // prints emptyspace
//		System.out.println(s.substring(-1,9)); a// throwing StringIndexOutOfBoundsException Exception:
		System.out.println(s.substring(0,0)); // prints emptyspace
//		System.out.println(s.substring(14,9)); // throwing StringIndexOutOfBoundsException Exception:
		
//		System.out.println(s.substring(0,-1));  // throwing StringIndexOutOfBoundsException Exception:
			System.out.println(s.substring(0,1));
		
		
		}
	
}