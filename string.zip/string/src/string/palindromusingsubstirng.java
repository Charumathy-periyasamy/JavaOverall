package string;

public class palindromusingsubstirng {

	 static void paliandrom(String s1, String s2)
	    { 
	          System.out.println("s1: "+  s1 + " s2: "+ s2);
	      int  lengthofs2 = s2.length();
	      if(s1.charAt(0)== s2.charAt(0))
	      {
	          System.out.println("s1.charAt(0): " + s1.charAt(0)+ "s2.charAt(0):" + s1.charAt(0));
	          
	      }
	      else{
	           System.out.println("Thes string is not a paliandrom");
	      }
	     
	       
	    }
		public static void main(String[] args) {
		//	System.out.println("Hello World");
		
		String s ="madham";

		int length = s.length();
			 System.out.println(s.charAt(length-1));
		
		if(s.charAt(0) == s.charAt(length-1))
		{
		   
		  
		    	for(int i =1;i<s.length();i++)
		{
		    System.out.println("came inside the for loop");

		     paliandrom(s.substring(i),s.substring(length-(i+1)));
		}

		   
		}
		else{
		     System.out.println("Thes string is not a paliandrom");
		}
		
		
		}
	}



