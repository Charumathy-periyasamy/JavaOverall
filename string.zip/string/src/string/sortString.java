package string;

import java.util.Arrays;

public class sortString {

	public static String stortWithoutUsingSortMethod(String s)
	{
		
		String ns = new String();
		char[] c = s.toCharArray();
		
		char temp;
		char g;
		char l;
		int f = c.length-1;
		
		System.out.println("length of char: "+ f);	
			for(int i =0;i<=c.length-1;i++)
			{
				 System.out.println("index of i:"+ i);
				for(int j=c.length-1; j> i && j>=0; j--)
				{
					
					if(c[i]>c[j])
					{
						System.out.println("c[i] : " + c[i]);
						System.out.println("c[j] : " + c[j]);
						temp = c[i];
					 g=	c[i] = c[j];
					 l=	c[j] = temp;	
					 	
					
					 System.out.println("index of j:"+ j);
					 System.out.println(" After swapping c[i] :" +c[i]);
					 System.out.println(" After swapping c[j] :" +c[j]);
					 System.out.println(c);
					}
					  // m a d  a m  -- aadam
					else 
					{
						
						 System.out.println("index of j in else statement:"+ j);
						continue;
					}
					
					
				}
			}
			String string = s.valueOf(c);
		 System.out.println("Reversed String : " + string);
		return string;
		

		
	}
	
	public static String sortUsingSortMethod(String si)
	
	{
	
		char[] ch = si.toCharArray();
		
		Arrays.sort(ch);
		
   return	String.valueOf(ch);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String resultWithoutUsingSort =	stortWithoutUsingSortMethod("ashogtajpkauyb");
	String resultUsingSort =	sortUsingSortMethod("GREEKPIOAJG");
	
	System.out.println("resultWithoutUsingSort : " + resultWithoutUsingSort);
	System.out.println("resultUsingSort : " + resultUsingSort);
				
	}

}
