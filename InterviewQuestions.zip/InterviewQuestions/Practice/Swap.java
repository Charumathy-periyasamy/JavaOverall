package Practice;

public class Swap {
 int tep;

	
	
public static void swapUsingThirdVariable(int a, int b)
{
	Swap s = new Swap();
s.tep = a;
	a=b;
	 b= s.tep;
	
	System.out.println("a: "+ a + "b: " + b);
	
}


public void swapWithOutUsingThirdVariable(int a, int b)
{
	System.out.println("Before swap: a: " + a + " b: " + b); 
 a = a+b ; // 10 + 15 = 25
b = a - b ; // 25 - 15 = 10
a = a - b; // 25 - 10 = 15

System.out.println("After swap: a: " + a + " b: " + b);
}
	
	
public static void main(String[] args) {
		// TODO Auto-generated method stub
Swap s = new Swap();
	swapUsingThirdVariable(10,15);
	s.swapWithOutUsingThirdVariable(10, 15);
	
	
	
	}

}
