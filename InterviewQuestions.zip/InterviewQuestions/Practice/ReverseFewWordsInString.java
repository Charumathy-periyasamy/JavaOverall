package Practice;

import java.util.Arrays;

public class ReverseFewWordsInString {

static	String toreverse = "My name is charumathy";
static	String reversed = "yM name is yhtamurahc";
static	String[] s = toreverse.split(" ");
	static char[]  c1 = s[0].toCharArray();
	static char[] c2 = s[s.length-1].toCharArray();
 	
	static public String res1(char[] ca)
	{
		
		for(int i =0;i<ca.length-1;i++)
		{
			
			System.out.println(ca[0]);
			System.out.println(ca[ca.length-1]);			
			char temp = ca[i];
			ca[i] = ca[ca.length-1];
			ca[ca.length-1] = temp;
		}
		for(char f : ca)
		{
		System.out.println("ca : "+ f);
		}
		
		
		return String.valueOf(ca);
	}

	
	static public String res2(char[] cb)
	{
		
		for(int i=0;i<(cb.length)/2;i++)
		{
			
			System.out.println("cb[0]"+cb[0]);
			System.out.println("cb[last]"
					+ cb[cb.length-1]);	
				
			char temp = cb[i];
			
			cb[i] = cb[(cb.length-1)-i];
			
			cb[(cb.length-1)-i] = temp;
			
			
			
		}
		for(char f : cb)
		{
		System.out.println("cb : "+ f);
		}
		
		
		return String.valueOf(cb);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String r1 = res1(c1);
		String r2 = res2(c2);
		
		System.out.println(r1);
		System.out.println(r2);	
		
		s[0] = r1;
		s[s.length-1] = r2;
		
		
		
		String result = s.toString();
		
		StringBuffer sb = new StringBuffer();
		
		for(String hj : s)
		{
			System.out.println(sb.append(hj));
		}
		System.out.println("coverting string  using string buffer " + sb.toString());
		
	  System.out.println("using Arrasys.toString" +Arrays.toString(s));  
		}

}
/*
// algorithn

s1: split the 'toreverse' into string[]
s2: fetch values of index 0 and length-1 in the string[]
s3: convert both the string[] into charArray
s4: work on bothe charArray and swap it using loop

*/