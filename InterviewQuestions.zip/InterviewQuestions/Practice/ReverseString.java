package Practice;


//Q1: Write a java program to reverse a string without using string inbuilt funcitons.

public class ReverseString {
	static String s1 = "HELLOWORLD";
	
 public static void usingStringBuilder()
 {
	 StringBuilder s2 = new StringBuilder();
	 s2.append(s1); // I can append the String to String builder but cannot assign
	 s2.reverse();
	 		
	 System.out.println(s2);
 
 }
 
 public static void usingcharAt()
 {
	 for(int i=s1.length()-1;i<=s1.length()-1 & i>=0;i--)
	 {
		 System.out.print(s1.charAt(i));  //System.out.print() is used for printing in same line
		 
	 
	 }
	 System.out.print("\n");
 }
 
public static void usingCharArray()
{
	char[] charr = s1.toCharArray();
	
	for(int i = charr.length-1;i<=charr.length-1 & i>=0;i--)
	{
		
	    System.out.print(charr[i]);	
	}
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
usingStringBuilder();
usingcharAt();
usingCharArray();
}

}
