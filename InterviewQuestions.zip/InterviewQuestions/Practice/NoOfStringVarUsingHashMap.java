package Practice;

import java.util.HashMap;

public class NoOfStringVarUsingHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s = "hello world";

String[] a = s.split(" ");
//int count = 0;

System.out.println("length: "+ s.length());

System.out.println(a.length);

HashMap<String,Integer> map= new HashMap<String, Integer>();

for(int i = 0; i<a.length;i++)
{
	if(map.containsKey(a[i]))
		
	{
		int count = map.get(a[i]);
		System.out.println(map.get(a[i]));
		count = count+1;
	}
	else
	{
		map.put(a[i], 1);
	}
}
System.out.println("map: "+ map);

		
	}

}
