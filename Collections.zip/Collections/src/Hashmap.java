import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("inside HASHMAP DEMO");
		
	Map<String, Integer> map = new HashMap<>(); // in HashMap<> not need to provide key and value as it be done automatically
	map.put(null, 25);
	map.put("Raj", 29);
	map.put("Anita", 25);
	map.put(null, 45);
	
	// update the key and value
	map.put(null, 25);
	
	// containsKey operation
	
	System.out.println("containsKey()"+ map.containsKey("Raj"));
	System.out.println("containsValue()" + map.get("John")); // will return 'null' as there is not key named 'John'
    System.out.println("containsvalue() "+ map.get("Raj"));
	
		System.out.println(map);
		
		System.out.println("Iterating using keyset");
		
		Set<String> name = map.keySet();
	
		
		System.out.println("set: "+ name);
		
		for(String s : name)
		{
			System.out.println("name: " + s + " age: "+ map.get(s));
			//System.out.println("name:" + name +"Age:" + map.get(name));
			
		}
		
		System.out.println("iterating using entrySet"); // will set of all mapping which will be the instance ENTRY interface
		
	Set<Map.Entry<String, Integer>> mapping = map.entrySet();  
		
		System.out.println("entryset: "+ mapping);
		
		for(Map.Entry<String, Integer> mapp : mapping)
		{
			System.out.println("name: " + mapp.getKey() + " age: "+ mapp.getValue());
			//System.out.println("name:" + name +"Age:" + map.get(name));
			
		}
		
	// in key set if any changes happend in the retured set that will impact parent also
		name.remove("Raj");
		
System.out.println("after removing raj "+ map);		


// having Map itself as a value

Map<String, Map<String, Object>> userprofile = new HashMap<>();

         Map<String, Object> profile = new HashMap<>();
         profile.put("age", 24);
         profile.put("dep", "CS");
         
         userprofile.put("John", profile);
         
         profile.put("age", 23);
         profile.put("dep", "Cs");
         
         userprofile.put("ram", profile);
         
         System.out.println(userprofile);

         // retrieve value of one key
         
         Map<String, Object> o = userprofile.get("John");
         System.out.println(userprofile.get("John"));
         
        System.out.println(o.get("age")); 
	}
}