import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class HashMapDemo {

	public static void hashMap() {
		Map<String, Integer> map1 = new HashMap<>();
		map1.put("John", 25);  
		map1.put("Raj", 29);
		map1.put("Anita", null);

		System.out.println("map1: " + map1);

// updating value of "Anita"

		map1.put("Anita", 20);
		System.out.println("Changed value of Anita, map1: " + map1);
		System.out.println("map1: " + map1);
		System.out.println("contains john: " + map1.containsKey("John"));

		System.out.println("get value of John: " + map1.get(25)); // if I provide the 'value' in the get(), not facing
																// any error but getting null value
		System.out.println("get vlaue of John " + map1.get("John"));

	
		
		// iterate using Collection<V> values();

		Collection<Integer> values = map1.values();
		for (Integer value : values) {
			
			//values.remove(value); // concurrent modification exception
			System.out.println("remove an element in map : " + map1.remove(value)); // this will always show null as we are passing VALUE instead of key 
		System.out.println(map1);
		
		if(map1.get("John").equals(value)) 
		{
	//	System.out.println(" values.remove(John) " + values.remove("John"));	 // nothing removed as this is the remove method in Collections
//			System.out.println(values.add("87")); // add() is not supported in map 
			
	//	map1.remove("John"); // showing concurrent modification exception
	//		map1.put("788", 98);  // showing concurrent modification exception
		
			System.out.println("authfdjpsioijjjjausdhgklasdlgalk"+map1);
		}
		
	//	map1.remove("John"); -- concurrent moldification
		System.out.println("authfdjpsioijjjjausdhgklasdlgalk"+map1);
	//	map1.put("99", 78); // concurrent modification exception
			System.out.println("values:  " + value);
		}

	
		
		// iterating using keySet()

		Set<String> keys = map1.keySet();
		for (String name : keys) {
			System.out.println("key : " + name + " value: " + map1.get(name) );
			// keys.remove("Anita"); // getting concurrentmodification exception
			
		//	map1.remove(name);      // getting concurrentmodification exception
		//	map1.put("oiuygyui", 76); // getting concurrentmodification exception
			
		}
		// removing the value: to know that the SET returned by keySet() is child of the
		// original map, means changes done in child will reflect in parent as well.

		keys.remove("Anita");
		System.out.println(map1);

		
		
		
// iterating using entrySet()	
		Set<Map.Entry<String, Integer>> mappings = map1.entrySet();

		for (Map.Entry<String, Integer> mapping : mappings) {
			System.out.println("keyfgh : " + mapping.getKey() + " value: " + mapping.getValue() );
			mapping.setValue(30);
			System.out.println("keyjjy : " + mapping.getKey() + " value: " + mapping.getValue());
			
			System.out.println("mappings.remove(mapping.getKey()) : " + mappings.remove(mapping.getKey()));  // remove() of SET is just returning false
	//	map1.remove(mapping.getKey()); // concurrent modification
		//	map1.put("aj", 89); // concurrent modification
			map1.put("John", 80);  // this will not show concurrent modification as we are updating here instead of adding (structural modification)
		}
		System.out.println("map1 after using setValue(): " + map1);
		// how the value itself a map

		Map<String, Map<String, Object>> userProfile = new HashMap<>();

		Map<String, Object> profile = new HashMap<>();
		profile.put("age", 30);
		profile.put("dept", "CS");
		profile.put("city", "Chennai");

		userProfile.put("John", profile);

		System.out.println(userProfile);

		profile.put("age", 26);
		profile.put("dept", "CS");
		profile.put("city", "Chennai");

		userProfile.put("Raj", profile);

		System.out.println(userProfile);

		// retreving values

		Map<String, Object> profile1 = userProfile.get("John");

		System.out.println("John : " + profile1);

		// extracting only age

		System.out.println(profile1.get("age"));

		// Bulk operations:

		Map<String, Integer> map2 = new HashMap<>();

		Map<String, Integer> map3 = new HashMap<>();

		map2.put("user1", 20);
		map2.put("use1.1", 87);

		map3.put("use2", 06);
		map3.put("user2.2", 04);

		System.out.println("map2: " + map2);
		System.out.println("map3: " + map3);

		map2.putAll(map3);

		System.out.println("map2 and map3 using putALL(): " + map2);

		map3.clear();

		System.out.println("map2: " + map2);
		System.out.println("map3: " + map3);

	}

	public static void LRCTest() {
		Map<String, String> map = new LinkedHashMap<>(16, 0.75f, true); // if the parameter is true then LInkedHashMap will behave a LRU Cache otherwise it won't
		map.put("a", "A");   // here we are using a limitless LRU Cache, to use limited size of Cache, we need create a sub class which will extend LinkedHashMap and overrdie the removeEldestEntry() method
		map.put("b", "B");
		map.put("c", "C");
		map.put("e", "E");
		
		System.out.println(map);
		
		map.put("a", "A");
		
		System.out.println(map);
		
		map.put("c", "CC");

		System.out.println(map);
		
		map.get("b");
		System.out.println(map);
		
	}
	
	
	public static void hashMapJavaConcept()
	{
// 1) Explain the different ways of creating HashMap in java?
		
		// creating HashMap using default initial capacity constructor:
		
		Map<String, String> map5 = new HashMap<>();  // here the defalut capactity = 16, load factor = 0.75
		
		// creating hashmap using only the initial capacity as input in the constructor HashMap(Map<? extends K,? extends V> m)
		
		Map<String, String> map6 = new HashMap<>(2);
		 
		map6.put("a", "A");
		map6.put("b", "B");
		
		// creating hashmap using the constructor HashMap(int capacity, float loadFactor)
		
		Map<String, String> map7 = new HashMap<>(20,0.5f);
		
		// creating hashmap using the constructor HashMap(Map<? extends K,? extends V> m)
		
		Map<String, String> map8 = new HashMap<>(map6);
		
		
// 2) How do you add key-value pairs to HashMap?
		
		map6.put("a", "SAA");
		map6.put("b", "B");
		
		map5.putAll(map6);
		map5.put("1", "one");
		map5.put("2", "two");
		
		System.out.println("map6" + map6);
		System.out.println("map5" +map5);
	
// 3) How do you add given key-value pair to HashMap if and only if it is not present in the HashMap?
		
		map5.putIfAbsent("3", "three");
		map5.putIfAbsent("1", "one");
		map5.putIfAbsent("2", "twoTwo");
		
	System.out.println("map5 to check putIfPresent() : "+ map5); // result the key value 2-twoTwo is not updated means this method is checking onnly the present of key
	
// 4) How do you retrieve a value associated with a given key from the HashMap?
	
	System.out.println(map5.get("1"));
	
// 5) How do you check whether a particular key/value exist in a HashMap?
	
System.out.println(map5.containsKey("1"));
System.out.println(map5.containsValue("one"));

// 6) How do you find out the number of key-value mappings present in a HashMap?

System.out.println("Size of map: " + map5.size());

// 7) How do you remove all key-value pairs from a HashMap? OR How do you clear the HashMap for reuse?

//map5.clear();

// 8) How do you retrieve all keys present in a HashMap?

Set<String> keys = map5.keySet();

for(String key: keys)
{


	System.out.println("keys; "+ key);
// keys.remove(key); // concurrent modificantion exception
	
	
}

System.out.println(keys);
System.out.println("without assinging the return key in any variable: "+ map5.keySet());
	
// 9) How do you retrieve all the values present in a HashMap?

Collection<String> values = map5.values();

System.out.println("values: "+ values);


// 10) How do you retrieve all key-value pairs present in a HashMap?

Set<Map.Entry<String, String>> mapping = map5.entrySet();

System.out.println("Retriving all mapping: " + mapping);

for(Map.Entry<String, String> mapp: mapping)
{
//	map5.remove("1");-- showing concurrent modificagion exception
//	map5.put("68", "0987"); -- showing concurrent modificagion exception
	System.out.println("map5 to check the put() while iteration : " + map5);
	System.out.println("key: key" + mapp.getKey() + " value: "+ mapp.getValue()) ;
/*
  if( 1 == 1)
{
	  System.out.println("apoioyfdydvgujiokdps");
	map5.put("ouiuygui", "rty");  ------------ concurrent moldification excetption, but for the same case getting proper result in keySet iteration
	System.out.println("avilgbuahijgdhulao;gji : "+ map5);
	
} */   
	

}



// 11) How do you remove a key-value pair from the HashMap?


//map5.remove("1");
map5.remove("2", "two");

System.out.println("map5 to check the remove() methods : "+ map5);


 
// removeing and adding while iteration


Set<String> set = map5.keySet();

for(String s: set)
{
	if(s.equals("3"))  //  -- this is not showing concurrent modification exception still it is making structual changes, becasue,, iterator will 
	{                 //  throw the correcut on next iteration oobly, but here the  input key itself the last key, so there is not next iteration
		System.out.println("a;hgkaijoigkhasdugh " + map5);
	//	set.remove(s);  // both are working
		map5.remove(s);  
		System.out.println("a;hgkaijoigkhasdugh " + map5);
		map5.put("s", "yes");
	}
	System.out.println("set to verfiy the remove() operation while iteration on SET" + map5);
}


// 12) How do you remove a key-value pair from a HashMap if and only if the specified key is currently mapped to given value?

//Another version of remove() method which takes two arguments � one is key and another one is value, 
// removes the mapping for the specified key only if it is currently mapped to given value.

map5.remove("s", "IJJ"); // not exist
map5.remove("s", "yes");

System.out.println("map5 after to check remove(key,value)"+ map5);


// 13) How do you replace a value associated with a given key in the HashMap?


map5.replace("a", "newA"); 

System.out.println("to check replace(key, value)" + map5);

map5.replace("f", "newA"); // it we change the key then nothing is getting replaces
System.out.println("to check replace(key, value)" + map5);

map5.put("f", "F");
map5.put("g", "G");

map5.replace("f", "F", "NewF");

System.out.println("to check replace(key, old value, new value)" + map5);

	}
	
	public static void LindkedHashMapDemo()
	{
		
		
	// 1. Constructors in LinkedHashMap
		
// default construcotr		
LinkedHashMap<Integer, String> linkedmap = new LinkedHashMap<Integer, String>();

//linkedmap.put(1, "one");
//Constructor with capacity as parameter

LinkedHashMap<Integer, String> linkmap1 = new LinkedHashMap<Integer, String>(16);

// Constructor with parameter as another map

LinkedHashMap<Integer, String> linkmap2 = new LinkedHashMap<Integer, String>(linkedmap);

// Constructor with capacity and load factor as parameter

LinkedHashMap<Integer, String> linkmap3 = new LinkedHashMap<Integer, String>(16, 0.75f);		
	
// constructor with parameter a capacity, load factor and boolean order (Refer the LRU test method for reference)


// 2.Adding Elements

linkmap1.put(2, "two");
linkmap1.put(3, "three");

System.out.println("checking put() : " + linkmap1);

linkmap2.putAll(linkmap1);

System.out.println("checking putAll() : " + linkmap2);


// 3. Changing/Updating elements


linkmap1.put(1, null);

System.out.println("checking the pul() for  updatibg : " + linkmap1);

// 4. remove elements

linkmap1.remove(1);
linkmap2.remove(linkmap1);  // not removed anything


System.out.println("removed one element in linkedhashmap : " + linkmap1);
System.out.println("removed elements of linkmap1 in linkmap2 : " + linkmap2);

linkmap2.remove(2, "two");
System.out.println("removed one element in linkedhashmap : " + linkmap1);


// 5. Iterating through linkedhash map

 
for(Map.Entry<Integer, String> mapelement: linkmap1.entrySet())
{
	System.out.println(mapelement.getValue());
	System.out.println(mapelement.getKey());
 
}



	}
	
	public static void sortedMapInterface()
	{
		// Default initialization of sortMap
		
		SortedMap smap1 = new TreeMap();
		SortedMap<String, String> smap2 = new TreeMap<String, String>();
// 1. adding elements and displaying it in ascending order using sortedMap		
		smap1.put(8, "one");
		smap1.put(0, "zero");
		smap1.put(2, "two");
		
		System.out.println("checking the sortedmap : " + smap1);
		
		System. out.println("checking smap2 : " + smap2);
		
		smap2.putAll(smap1);
		
		System.out.println("checking smap2 : " + smap2);
		
// updating the values
		
		smap1.put(2, "twotwo");
		System.out.println( "changing the key value : " + smap1);
		
		
		smap1.putIfAbsent(7, "seven");
		
		System.out.println(smap1);
		
// remove() the element
		
		smap1.remove(9);
		System.out.println("checking remove(K) : " + smap1);
		
		smap1.remove(7, "seven");
		
		System.out.println("checking remove(K, V) : " + smap1);
		
// Iterating through the sorted map
		
		Set<Object> s = smap1.keySet();
		
		for( Object m : s)
			
		{
		
			System.out.println("inside for eachloop using keySet() : " + smap1.get(m));
			
		
		}
			
		
		
		System.out.println(smap1.getOrDefault(2, "one"));
		System.out.println(smap1.get(3));
		
		Iterator<Map.Entry<Integer, String>> it = smap1.entrySet().iterator();
		System.out.println(smap1);
		while (it.hasNext())
		{
		  if(it.next().getKey().equals(2)) 
		  {
			   // it.remove();
			  smap1.remove(it.next().getKey());
			 
			  System.out.println("removing while iteration" + smap1);
		  }
		  System.out.println("removing while iterationjkjhn" + smap1);
		}

		Set<Integer> set1 = smap1.keySet();

		for(Integer s1: set1)
		{
			if(s1.equals(0))
			{
				
			//	smap1.put(2, "jalf"); // here using put() we just updating the existing value so, this will not throw concurrent modification error
			// but if we try to add one new element in map using put() method, will get conncurrent modification exception	
				System.out.println("set to verfiy the put() operation while iteration on SET" + smap1);
				
			
			//System.out.println("alsidhgoa[pkjalgfsl" + set1.remove(s1));
			
			
	//		smap1.remove(s1);
				
			//	smap1.remove(0); -- showing concurrent modification exceptionn because this remove() method will do changes in structure of Map
						
			}
			
		}

		
		
		
		  Set<Map.Entry<Integer, String>> entrymap = smap1.entrySet();
		  
		  for(Map.Entry<Integer, String> k : entrymap) {
		  System.out.println(k.getKey());
		  System.out.println(k.getValue());
		  System.out.println("getorDefault() "+smap1.getOrDefault(k.getKey(), k.getValue()));
		  
		  k.setValue("twotwo2");
		  
		  System.out.println(smap1);
		  
		  if(k.getValue()== "twotwo")
		  { 
			  System.out.println("inside the entryset of sortedMap method");
			  smap1.remove(k);
		  }
		  System.out.println("removing while iterations: " + smap1);
		  
		  
		  }
		 
		
	}
	
	public static void TreeMapImplementation()
	{
		TreeMap<String, String> treemap1 = new TreeMap<String, String>();
		
// 1. adding and printing elements		
		
		treemap1.put("7", "seven");
		treemap1.put("0", "zero");
		treemap1.put("3", "three");
		treemap1.put("8", "eight");
		treemap1.put("1", "one");
		treemap1.put("5", "five");
		
		for(Map.Entry<String, String> map : treemap1.entrySet())
		{
			System.out.println("printing the elements of TreeMap : Key:  " + map.getKey() + " value : " + map.getValue());
		}

// 2. remove() method
		
		treemap1.remove("3");
		
		System.out.println("printing the TreeMap elements after using remove() : " + treemap1);

// implementing Navigable Interface using TreeMap class --
//3. prints the TreeMap in descending order
		
		System.out.println("descendingMap() feature of NavigableMap Interface : " + treemap1.descendingMap());
		
// 4. Returns key-value pairs whose keys are less than or equal to the specified key.		
		
	System.out.println(treemap1);
		System.out.println(" headMap() " + treemap1.headMap("5")); // will print the Entry whose key is less than the input key
	
	System.out.println(" headMap() " + treemap1.headMap("5", true)); //will print the Entry whose key is less than the input key ,  if FALSE 
	 // will print the Entry whose key is less  than and equal to  the input key , if TRUE
	
// 5. Returns key-value pairs whose keys are greater than or equal to the specified key.  
	
	System.out.println(treemap1);
	System.out.println(" tailMap() " +treemap1.tailMap("5")); // will print the Entry whose key is greater than and equal to the input key
	System.out.println( " tailMap() " + treemap1.tailMap("5", false));  //will print the Entry whose key is less than the input key ,  if FALSE 
	 // will print the Entry whose key is less  than and equal to  the input key , if TRUE
	
System.out.println(treemap1.subMap("0", "7"));	// returing the sub map including the fromKey  and excluding the toKey
System.out.println(treemap1.subMap("0", false, "7", false));

// 6. iterating over the TreeMap()

for(Map.Entry<String, String> tree : treemap1.entrySet())
{
	System.out.println("key : " + tree.getKey() + "value() : " + tree.getValue() );
	tree.setValue("akjhgki"); // setting value fo r all the keys
	 System.out.println(treemap1);
}

System.out.println(treemap1);
System.out.println(treemap1.firstKey());
System.out.println(treemap1.lastKey());
System.out.println(treemap1.firstEntry());
System.out.println(treemap1.lastEntry());

System.out.println(treemap1.pollFirstEntry());
System.out.println(treemap1);
System.out.println(treemap1.pollLastEntry());
System.out.println(treemap1);


	
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

   //  hashMap();
	//	LRCTest();
	//	hashMapJavaConcept();
		LindkedHashMapDemo();
	//	sortedMapInterface();
	//	TreeMapImplementation();
	}

}
