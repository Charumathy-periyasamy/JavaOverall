import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratingOverArrayList  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	List<String> tvShows = new ArrayList<String>();
	tvShows.add("show1");
	tvShows.add("show2");
	tvShows.add("show3");
	tvShows.add("show4");
	tvShows.add("show5");
	
	
	System.out.println(tvShows);
// lets iterate over the list using iterator()
	Iterator<String> it = tvShows.iterator();

// using while loop	
	
	while(it.hasNext())
	{
		System.out.println("inside while loop using iterator");
		String nextitem = it.next();
		System.out.println(nextitem);
		
		if(nextitem.equals("show3"))
		{
			it.remove();
			
		}
		
		
	}
	
	System.out.println(tvShows);
	
// using for each	
	
	for(String s : tvShows)
	{
		System.out.println("inside foreach loop");
		System.out.println(s);
		
	/*	if(s.equals("show3"))
		{
			it.remove();
			
		}   */
	}
	System.out.println("after removing show3"+tvShows);

	}
	
	}

