import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] stringarray = {"test","summer","listkist"};
		LinkedList<String> ll =  new LinkedList<String>(Arrays.asList(stringarray)); 
		
		LinkedList<String> list1 = new LinkedList<String>();
		list1.add("a");
		list1.add("b");
		list1.add("c");
	
// ADD ELEMENTS IN THE LIST -- USED ALL THE ADD METHOD
		ll.add("Java");
		ll.add("Python");
		ll.add("JAVASCRIPT");
		
		System.out.println(ll);
		
		ll.add(0, null);
		
		System.out.println(ll);
		
		ll.addAll(ll);
		System.out.println(ll);
		ll.addAll(list1);
		
		ll.addAll(0, ll);
		System.out.println(ll);
		
		ll.addFirst("first test");
		System.out.println(ll);
		
		ll.addLast("last test");
		System.out.println(ll);
		
		
// GET AND SET ITEMS IN THE LIST	
		
	System.out.println(ll.get(0));	
	ll.remove(0);
		System.out.println(ll.getFirst());
		System.out.println(ll.getLast());
	
		
// 	REMOVE FROM A POSITION
		
		ll.remove("last test");
		System.out.println("removing last test" +ll);
		ll.remove(0);
		System.out.println("removing value at '0' th index" +ll);
		ll.remove(list1); // not removing
		System.out.println("removing object" +ll);
		ll.removeAll(list1);
		System.out.println("removing collection" +ll);  // removed list1 from the list
		
	    ll.removeFirst();
	    System.out.println("removing first" +ll);
	    
	    ll.removeLast();
	    System.out.println("removing last " +ll);
	    
	    
	   ll.removeFirstOccurrence("summer"); // if a specific element apprears more than 1 time...,this method is used to remove the firt occurenace
	   System.out.println("removing first occurance " +ll);
	   
	   ll.removeLastOccurrence("summer");
	   System.out.println("removing last occurance " +ll);
	  
	   ll.remove("summer");
	   System.out.println("removing object" +ll);
	
	}

}


/*

 1.  ll.addLast("C");
	ll.addFirst("D");
    ll.add(2, "E");
		System.out.println(ll);   
OUTPUT:  [D, C, E]

2. 	ll.addLast("C");
ll.addFirst("D");
ll.add(0, "E");
	System.out.println(ll);
	
OIUTPUT: [E, D, C]

		
3. ll.addLast("C");
ll.addFirst("D");
ll.add(1, "E");
	System.out.println(ll);
	
OUTPUT; [D, E, C]


*/