import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Arraylist {
	
	static List<Integer> list1 = new ArrayList<>();
	static List<Integer> list2 =  new ArrayList<>();

// Postitional operations	
	private static void arrayListDemo()
	{
		Collection<Integer> list1 = new ArrayList<>();
// basic operations		
		list1.add(1);  
		list1.add(2);    
		list1.add(4);
		list1.add(4);   // arraylsit can add duplicates and null values
		list1.add(null);
		
		System.out.println(list1.add(6)); // adding the element at last  -- return true if the element is added and there is no duplliates
		System.out.println("list1"+list1);
	// contains	
		System.out.println("contains method: "+list1.contains(2)); // return true or false
	//isEmpty()
		System.out.println("isEmpty method: "+list1.isEmpty()); // returns true or false
		System.out.println(list1.remove(4)); // will remove only the Integer 4. --- removed the first integer
		System.out.println("list1"+list1); 
		
		
	
		
	}
	
	private static void arraylisttoremoveaccordingtoindex()
	{
		
		
// Postitional operations	for list interface		
		list1.add(1);
		list1.add(2);   
		list1.add(4);
		list1.add(4);   // arraylsit can add duplicates and null values
		list1.add(null);
		System.out.println("list1"+list1);
		System.out.println(list1.remove(4)); // will remove the element at 4th index  
		System.out.println("list1"+list1); 
	// add method	
		list1.add(0, 9);  // will add the interger 9 at the 0th index5
	
		System.out.println("list1"+list1); 
		list1.set(0, 10);  // will set the interger 10 at the 0th index5 -- it will return the previous value of the changed index
		System.out.println("list1"+list1); 
// get method		
		System.out.println(list1.get(0)); // will show indexoutofbound exception if we pass the index greater than the length of the list
// set method
		System.out.println(list1.set(0, null));  // will print 10 as set method will return the previous element in the specified index
		// willl show index out of bound 5if index value is greater than the list length
//add(E element)
		System.out.println(list1.add(97)); // will add this interger at the end of the list
		System.out.println("list1"+list1); 
		System.out.println(list1.add(97));
		System.out.println(list1.add(97));
		System.out.println(list1.add(97));
		System.out.println(list1.add(97));
		System.out.println(list1.add(97));
		System.out.println(list1.add(98));
		System.out.println("list1"+list1); 
		System.out.println("list1"+ list1.size());
		list1.addAll(5, list1);
		System.out.println("list1"+list1); 
		
		
		
		}
	
// bulk operations	
	
	private static void listbulkoperation()
	{
		list1.add(1);
		list1.add(4);
		list1.add(7);
		list2.add(null);
		list2.add(1);
		list2.add(7);
		System.out.println("list1:"+ list1);
		System.out.println("list2:"+ list2);
// remove all method		
		System.out.println("remove all"+list1.removeAll(list2));
		System.out.println("list1:"+ list1);
		System.out.println("list2:"+ list2);
		list2.add(5);
		list2.add(4);
		list2.add(1);
		System.out.println("list2:"+ list2);
// retain all method		
		System.out.println("retail all method:"+list1.retainAll(list2)); // will print the element in list1 which is commonn to list2
		System.out.println("list1:"+ list1);
		list2.add(3);
// add all method
		System.out.println(list1.addAll(list2));
		System.out.println("list1:"+ list1);
		
		
	}
	
	private static void searchelement()
	{
		list1.add(1);
		list1.add(null);
		list1.add(5);
		list1.add(1);
		System.out.println("list1: "+ list1);
		System.out.println("contains method: "+ list1.contains(1));
		System.out.println("indexOf method :" + list1.indexOf(9)); // return -1 if the specified element is not in the list
		System.out.println("indexOf method :" + list1.indexOf(1)); // duplicate elements are there then the index of first element will be retured
		System.out.println("lastindexOf: "+ list1.lastIndexOf(1)); // return -1 if the specified element is not in the list
		
		
	}
	
	private static void rangeviewoperation()
	{
		list1.add(1);
		list1.add(9);
		list1.add(5);
		list1.add(1);
		 System.out.println("list1:" + list1);
	   List<Integer> list3 = list1.subList(0, 3);  // 0 is inclisive and 3 is exclusive
	    System.out.println("list3:" + list3);
	    System.out.println(list3.indexOf(9));
	    
	   list3.set(0, 7);
	   System.out.println("list3:" + list3);
		  System.out.println("list1:" + list1);
	   list3.add(1, 3);   // this will affetect the list3 also in the list1-- insert the value '3' at both the list
	   
	   System.out.println("list3:" + list3);
	  System.out.println("list1:" + list1);
	  
	  list1.set(2,10);
	  System.out.println("list3:" + list3);
	  System.out.println("list1:" + list1);
		
		  list1.add(0,1); // adding or deeleting the element (structural chaanges is will not reflect in list3 (child list) it will show expception
	//	 System.out.println("list3:" + list3); //// we can set something in the list1 but adding and deleting will show concurrent exception
		  System.out.println("list1:" + list1); // facing concurrent modificatiion exception when i add/remove element form list1 and try to print list3
		  
		
		  for(int element : list1) 
		  {
			  System.out.println(element); 
		  if(element == 5) 
		  
		 {
			  
		//  System.out.println(list1.remove(element)); // will sh9w  concurrentmodification Exception // here the remove() method is showing index out of bound exception but the below valueof method is working 
		  // to remove	 the element inside the loop we need to use iterator method
		//  list1.remove(Integer.valueOf(element)); 
		System.out.println("valueof"+Integer.valueOf(element));
		 System.out.println(list1.remove(element));
		  System.out.println("list1:" + list1);
		  }
		 }    
		   
	  // to remove an integer during the iteration it is not possible to do it using FOR EACH LOOP we should use ITERATOR METHOD
	}
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		arrayListDemo();
	//	arraylisttoremoveaccordingtoindex();
	//	listbulkoperation();
		//searchelement();
	//	rangeviewoperation();
	}

}
