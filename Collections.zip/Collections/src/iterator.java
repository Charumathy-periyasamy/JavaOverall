import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

public class iterator implements Iterable<Integer> {

	static List<Integer> list1 = new ArrayList<>();
	static List<Integer> list2 = new ArrayList<>();

	public Iterator<Integer> iterator() {
		return new ArrayList().iterator();
	}

	private static List rangeviewoperation() {
		list1.add(1);
		list1.add(9);
		list1.add(5);
		list1.add(1);
		System.out.println("list1:" + list1);
		List<Integer> list3 = list1.subList(0, 3); // 0 is inclisive and 3 is exclusive
		System.out.println("list3:" + list3);
		System.out.println(list3.indexOf(9));

		list3.set(0, 7);
		System.out.println("list3:" + list3);
		System.out.println("list1:" + list1);
		list3.add(1, 3); // this will affetect the list1 also in the list1 the value null and 5 will get
							// replace into 7 and 3

		System.out.println("list3:" + list3);
		System.out.println("list1:" + list1);

		list1.set(2, 10);
		System.out.println("list3:" + list3);
		System.out.println("list1:" + list1);

		list1.add(0, 1); // adding or deeleting the element (structural chaanges is will not reflect in
							// list3 (child list) it will show expception
		//  System.out.println("list3:" + list3); //// we can set something in the list1  but adding and deleting will show concurrent exception
		 System.out.println("list1:" + list1); // facing concurrent modificatiion
		// exception when i add/remove element form list1 and try to print list3

//		

//		  for(int element : list1) { // the list1 object will internally call iterator() method // that will throw the concurrent modification exception
//		  {
//		  System.out.println(element); 
//		  if(element == 3)

//		  {

//		  System.out.println(list1.remove(element)); // will sh9w concurrentmodification Exception // here the remove() method is showing indexout of bound exception but the below valueof method is working 
//		  // to removethe element inside the loop we need to use iterator method
//		  list1.remove(Integer.valueOf(element));
//		  }
//		  } 
		// to remove an integer during the iteration it is not possible to do it using
		// FOR EACH LOOP we should use ITERATOR METHOD

//		  }
		return list1;

	}

	private static void iteratorDemo(List<Integer> list1) {

		Iterator<Integer> iterator = list1.iterator();
		System.out.println("list inside iterator" + list1);
		while (iterator.hasNext()) {
			int element = iterator.next();
			System.out.println("element:" + element);

			if (element == 10) {
				list1.set(0, 23);
				int n = iterator.next();
				System.out.println("list inside iterator" + list1);
				iterator.remove(); // due to the above line -- it is removing 5 in the list.. otherwise it will
									// remove 10 from ethe list
				list1.set(1, 23);
				System.out.println("list inside iterator" + list1);
				iterator.forEachRemaining(Filter::add); // --> will add 7 with the remaining elements
				// list1.add(10); --- we can't add using iterator-- will show concurrent
				// modification exception
				System.out.println(list1);

				// iterator.forEachRemaining(null); -- will do somme operation on the elements
				// which is present after remove opeation
			}
		}
		list1.forEach(System.out::println); /// list1.forEach(new println); --> can be declared like this also
		list1.forEach(Filter::filter);

	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		 rangeviewoperation();

		List<Integer> list1 = rangeviewoperation();
	//	iteratorDemo(list1);

	}

}

//	public class Filter implements Consumer {

//		static void filter(Integer i)
//		{
//			if(i==1)
//			{
//				System.out.println(i);

//			}
//		}

//		static void add(Integer i)
//		{
//			System.out.println(i+7);
//		}

//		@Override
//		public void accept(Object t) {
// TODO Auto-generated method stub

//		}
//	}
