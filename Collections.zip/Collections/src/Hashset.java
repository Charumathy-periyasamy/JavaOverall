import java.util.*;

public class Hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        // Creating an empty HashSet
        HashSet<String> h = new HashSet<String>();
 
        LinkedHashSet<String> s = new LinkedHashSet<String>();
        
       
        
        // Adding elements into HashSet
        // using add() method
        h.add("India");
        h.add("Australia");
        h.add("South Africa");
 
        // Adding duplicate elements
        h.add("India");
 
        
        
        // Displaying the HashSet
        System.out.println(h);
        System.out.println("List contains India or not:"
                           + h.contains("India"));
 
        // Removing items from HashSet
        // using remove() method
        h.remove("Australia");
        System.out.println("List after removing Australia:"
                           + h);
        
        
 
        // Display message
        System.out.println("Iterating over list:");
 
        // Iterating over hashSet items
        Iterator<String> i = h.iterator();
 
        // Holds true till there is single element remaining
        while (i.hasNext())
 
            // Iterating over elements
            // using next() method
            System.out.println(i.next());
    }

		
		
	}

