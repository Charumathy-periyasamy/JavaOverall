import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Queue;

public class Arraydeque  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Deque<String> deque = new ArrayDeque<>();
		
		// FIFO
		deque.add("one");
		deque.add("two");
		deque.add("three");
		
		System.out.println("Printing deque");
		System.out.println("deque::"+ deque);
		
	// removing head element
		
		System.out.println(deque.remove()); // will remove the head element
		
		System.out.println(deque.remove());
		System.out.println(deque.remove());

		
	
	System.out.println("deque:" + deque);
	
	// LIFO -- STACK
	
	deque.push("one");
	deque.push("two");
	deque.push("three");
	
	System.out.println("Printing STACK");
	System.out.println("deque::"+ deque);
	
	// removing head
	System.out.println(deque.pop()); // will remove the head element
	
	System.out.println(deque.pop());
	System.out.println(deque.pop());
	
	System.out.println("deque:" + deque);
	deque.push("one");
	deque.push("two");
	deque.push("three");
	
// METHODS OF QUEUE INTERFACE WHICH IS INHERITED FROM COLLECTION
	
	
// to insert or add element on TAIL
	
  Queue<Integer> queue = new ArrayDeque<Integer>(1);  // '1' is the initial capacity

// insert methods -- 

  queue.add(1);
  // queue.addAll(deque); 
  System.out.println("queue add " + queue);
  
 // adding element using offer(e) method 
  
 // queue.offer("offer");
  queue.offer(2);
  queue.offer(3);
  queue.offer(4);
  queue.offer(5);
  queue.offer(6);

  System.out.println("queue add " + queue);
	
	
 // REMOVING elements in queue
  
  queue.remove();  // removed the head element
  System.out.println("queue remove " + queue);
  
  queue.remove(4);  // removed the middle // any specified element\
  System.out.println("queue remove(object) " + queue);
  
  queue.removeAll(queue);
  System.out.println("queue removeAll " + queue);  // remove every elements in the queue

  //queue.remove(); // trying to remove the head element on the empty queue  // got NoSuchElementException
  queue.poll();  //  poll() wil return NULL  if queue is empty
  System.out.println("queue poll() " + queue +  queue.poll());
  
  
 // RETRIEVE  THE HEAD ELEMENT
  
//  queue.element();  // trying to retrive the head element on the empty queue  // got NoSuchElementException
 queue.peek();
  
  System.out.println("queue.peek()"+queue.peek());
  queue.add(9);
  queue.add(8);
  queue.add(5);
  
  System.out.println(queue);
  
 queue.peek();
  
  System.out.println("queue.peek()"+queue.peek());
 
  
//  ******************************************* DEQUE METHODS ***************************
  // deque can manipulat both head and tail
  Deque<String> d = new ArrayDeque<String>();
  
  d.add("one");
  d.add("two");
  d.add("three");
  d.add("two");
  
  System.out.println("d"+d);
  // adding elements  head 
  
  d.addFirst("first");
  System.out.println("addfurst"+d);
 // d.addLast("last");
  d.offerFirst("offer first");
  
  System.out.println("offerfirst"+d);
 // d.offerLast("offer last");
  
 
  //removing head
  
  d.removeFirst();
  
  System.out.println("removefirst"+d);
  d.removeFirstOccurrence("two"); // will remove the first occurance of the specified element
  
  System.out.println("remove first occurance"+ d);
  
  // retrieving head element
  
  d.getFirst();
  
  System.out.println("getfirst"+  d.getFirst());
  
 // adding tail element
  
  d.addLast("tailone");
  d.offerLast("offer last");
  d.addLast("tailone");
  d.addLast("recently added");
  
  System.out.println("tail elements:" + d);
  
  // retrieving tail element
  
  d.getLast();
  System.out.println("getlast" + d.getLast());
  System.out.println("getlast"+ d);
  
  d.peekLast();
  
  System.out.println("peekladt"+ d.peekLast());
  
  //remove the tail element
  
  d.removeLast();
  
  System.out.println("removelast"+ d);
  
  d.pollLast();
  
  System.out.println("polllast"+ d);
  
  
	}

}
